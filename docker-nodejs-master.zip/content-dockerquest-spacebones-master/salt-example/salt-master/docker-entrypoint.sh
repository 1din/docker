#!/bin/bash

/etc/init.d/salt-minion start
/etc/init.d/salt-master start

/bin/bash
