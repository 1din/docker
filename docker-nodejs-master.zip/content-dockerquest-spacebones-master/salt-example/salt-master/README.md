Includes the Salt Master and sshd.

