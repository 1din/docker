#!/bin/bash

/etc/init.d/salt-minion start

/bin/bash
