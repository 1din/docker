# doge
This is an nginx docker container to serve up the doge
Such Docker
Many Nginx
## Doge Nginx Dockerfile


This repository contains and editeed version of **Dockerfile** of [Nginx](http://nginx.org/) for [Docker](https://www.docker.com/)'s [automated build](https://registry.hub.docker.com/u/dockerfile/nginx/) published to the public [Docker Hub Registry](https://registry.hub.docker.com/), forked from [jeremy646/doge](https://hub.docker.com/r/jeremy646/doge).


### Base Docker Image

* [dockerfile/ubuntu](http://dockerfile.github.io/#/ubuntu)


### Installation

1. Install [Docker](https://www.docker.com/). (for Debian/Ubuntu apt-get update; apt-get install docker.io)

2. Download [automated build](https://registry.hub.docker.com/u/TOBECOMPLETED) from public [Docker Hub Registry](https://registry.hub.docker.com/): `docker pull spacebones/doge`

### Usage

    docker run -d -p 80:80 spacebones/doge
